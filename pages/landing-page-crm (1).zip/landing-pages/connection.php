
<?php 
$con=mysqli_connect("localhost","nwoowcom_rkelectrocare","rkelectrocare@12","nwoowcom_rkelectrocare") or die('DATABASE connection failed');


  date_default_timezone_set("Asia/kolkata"); 
?>
