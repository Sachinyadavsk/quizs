<footer class="footer">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <script>document.write(new Date().getFullYear())</script> © rkelectrocare.
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end d-none d-sm-block">
                            Crafted with <i class="mdi mdi-heart text-danger"></i> by <a href="" target="_blank" class="text-muted">rkelectrocare</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    </div>
    <!-- end main content-->
</div>
<!-- end layout-wrapper -->



<!-- JAVASCRIPT -->
<script src="https://rkelectrocare.com/assets/libs/jquery/jquery.min.js"></script>
<script src="https://rkelectrocare.com/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://rkelectrocare.com/assets/libs/metismenu/metisMenu.min.js"></script>
<script src="https://rkelectrocare.com/assets/libs/simplebar/simplebar.min.js"></script>
<script src="https://rkelectrocare.com/assets/libs/node-waves/waves.min.js"></script>


<!-- apexcharts -->
<script src="https://rkelectrocare.com/assets/libs/apexcharts/apexcharts.min.js"></script>

<script src="https://rkelectrocare.com/assets/js/pages/dashboard.init.js"></script>

<!-- App js -->
<script src="https://rkelectrocare.com/assets/js/app.js"></script>

    <!-- Required datatable js -->
    <script src="https://rkelectrocare.com/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>

    <!-- buttons examples -->
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js"></script>
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

    <!-- Responsive examples -->
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="https://rkelectrocare.com/assets/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js"></script>

    <!-- Datatable init js -->
    <script src="https://rkelectrocare.com/assets/js/pages/datatables-advanced.init.js"></script>

<!-- Sweet Alerts js -->
<script src="https://rkelectrocare.com/assets/libs/sweetalert2/sweetalert2.min.js"></script>

<!-- Sweet alert init js-->
<script src="https://rkelectrocare.com/assets/js/pages/sweet-alerts.init.js"></script>
<script src="https://rkelectrocare.com/assets/js/pages/form-validation.init.js"></script>

</body>

</html>