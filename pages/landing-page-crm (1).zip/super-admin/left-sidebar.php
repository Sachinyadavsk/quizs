    <?php require('connection.php');?>
    <!-- ========== Left Sidebar Start ========== -->
    <div class="sidebar-left">

        <div data-simplebar class="h-100">

            <!--- Sidebar-menu -->
            <div id="sidebar-menu">
                <!-- Left Menu Start -->
                <ul class="left-menu list-unstyled" id="side-menu">
                    <li>
                        <a href="dashboard" class="">
                            <i class="fas fa-desktop"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>


                  

                    
                    <li>
                        <a href="agencies"><i class="fas fa-building"></i> <span>Agencies</span></a>
                    </li>

                    <li>
                        <a href="javascript:void(0);" class="has-arrow"><i class="fas fa-users"></i> <span>Pages</span></a>
                           <ul class="sub-menu" aria-expanded="false">
                             <li><a href="pages"><i class="mdi mdi-checkbox-blank-circle align-middle"></i>All Pages</a></li>
                        </ul>
                    </li>
<li>
                        <a href="javascript:void(0);"class="has-arrow "><i class="fas fa-pager"></i> <span>Leads</span></a>
                         <ul class="sub-menu" aria-expanded="false">
                         <li><a href="leads"><i class="mdi mdi-checkbox-blank-circle align-middle"></i>All Leads</a></li>
                        </ul>
                    </li>
           
                </ul>
            </div>
            <!-- Sidebar -->
        </div>
    </div>
    <!-- Left Sidebar End -->