<?php 
session_start();
if(isset($_SESSION['SUPER_ADMIN_LOGIN'])&&$_SESSION['SUPER_ADMIN_LOGIN']=='yes'){
?>
<?php require('connection.php');?>
<?php require('html-header.php');?>
<?php require('top-header.php');?>
<?php require('left-sidebar.php');?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                
                <div class="row">
                            <div class="col-12">
                                <div class="card" style="height: 495px; overflow: hidden auto;" data-simplebar="init">
                                    <div class="card-header">
                                        <div class="card-icon text-muted"><i class="fas fa-sync-alt fs-14"></i></div>
                                        <h3 class="card-title">Pages</h3>
                                        <!--<div class="card-addon dropdown">
                                            <a href="javascript:void();" data-bs-toggle="modal" data-bs-target="#modal00">
                                            <button class="btn btn-label-success btn-sm"> <i class="fas fa-plus fs-12 align-middle ms-1"></i></button>
                                            </a>
                                        </div>-->
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive-md">
                                            <table id="datatable-col-visiblility" class="table text-nowrap mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Agency</th>
                                                        <th>Name</th>
                                                        <th>Logo</th>
                                                        <th>Banner</th>
                                                        <th>Image</th>
                                                         <th>Key Feature 1</th>
                                                        <th>Key Feature 2</th>
                                                        <th>Key Feature 3</th>
                                                        <th>Key Feature 4</th>
                                                        <th>Page URL</th>
                                                        <th>Postback URL</th>
                                                        <th>Added On</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                               <?php
                                                $cat_res=mysqli_query($con,"select * from pages order by id desc");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $list){
                                                     $c_id=$list['agency_id'];
                                                      $cat_res=mysqli_query($con,"select * from agency where id='$c_id'");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $listv){
                                                     $aname=$listv['name'];
                                                 $agnid=$listv['id'];
                                                 $alp=$listv['allowed_pages'];
                                                ?>
                                                    <tr>
                                                        <td class="align-middle"><?php echo $aname;?></td>
                                                       <td class="align-middle"><?php echo $list['name'];?></td>
                                                        <td class="align-middle"><img src="../uploads/<?php echo $list['logo'];?>" width="100%"></td>
                                                       
                                                        <td class="align-middle"><img src="../uploads/<?php echo $list['banner'];?>" width="100%"></td>
                                                        <td class="align-middle"><img src="../uploads/<?php echo $list['image'];?>" width="100%"></td>
                                                        <td class="align-middle"><?php echo $list['kf1'];?></td>
                                                        <td class="align-middle"><?php echo $list['kf2'];?></td>
                                                        <td class="align-middle"><?php echo $list['kf3'];?></td>
                                                        <td class="align-middle"><?php echo $list['kf4'];?></td>
                                                        <td class="align-middle">https://drive360.in/landing-pages/<?php echo strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $listv['name'])));?>/<?php echo strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $list['name']))); ?></td>
                                                        <td class="align-middle"><?php echo $list['url'];?></td>
                                                        <td class="align-middle"><?php echo $list['timestamp'];?></td>
                                                        <td class="align-middle"><?php echo $list['status'];?></td>
                                                       
                                                       
                                                        <td class="align-middle">
                                                           
                                                            <?php if($list['status']==1){?>
                                                            <form action="" method="post">
                                                                <input type="hidden" value="<?php echo $list['id'];?>" name="deleteid">
                                                           <button type="submit" name="lead-delete" style="border:none;">Active
                                                            </button>
                                                            </form>
                                                          <?php }else{?>
                                                          <form action="" method="post">
                                                                <input type="hidden" value="<?php echo $list['id'];?>" name="activeid">
                                                           <button type="submit" name="lead-active" style="border:none;">Deactive
                                                            </button>
                                                            </form>
                                                            <?php }?>
                                                        </td>
                                                         <td class="align-middle">
                                                            
                                                            <form action="" method="post">
                                                                <input type="hidden" value="<?php echo $list['id'];?>" name="deleteid">
                                                           <button type="submit" name="lead-deletee" style="border:none; background:none;"><i class="fas fa-trash" style="color:red"></i>
                                                            </button>
                                                            </form>
                                                            <?php 
                                                            $pagecount=0;
                                                                $cat_res=mysqli_query($con,"select * from pages where agency_id='$agnid'");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $list){
                                                     $pagecount++;
                                                     
                                                 }
                                                            if($pagecount<$alp){
                                                            ?>
                                                            <a href="javascript:void();" data-bs-toggle="modal" data-bs-target="#modal<?php echo $listv['id'];?>">
                                                            <i class="fas fa-plus fs-12 align-middle ms-1"></i>
                                                            </a>
                                                            <?php }?>
                                                        </td>
                                                    </tr>
                                                   <?php }}?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        
                    
                    </div>
                    </div>
                    </div>
                   
                </div>
                                 <?php 
                                       $cat_res=mysqli_query($con,"select * from agency");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $listv){
                                                     ?>
                       <div class="modal fade" id="modal<?php echo $listv['id'];?>">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">User</h5><button type="button" class="btn btn-sm btn-label-danger btn-icon" data-bs-dismiss="modal"><i class="mdi mdi-close"></i></button>
                            </div>
                            <div class="modal-body">
                                <div class="card">
                            <div class="card-body">
                                <form class="needs-validation" action="" method="post" enctype='multipart/form-data' novalidate>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="validationCustom01" class="form-label">Name</label>
                                                <input type="text" class="form-control" id="validationCustom01" name="name" placeholder="Name" required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Logo</label>
                                                <input type="file" class="form-control" id="validationCustom02" name="logo" required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="validationCustom01" class="form-label">Banner</label>
                                                <input type="file" class="form-control" name="banner" id="validationCustom" required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Image</label>
                                                <input type="file" class="form-control" id="validationCustom" name="image" required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                      <div class="row">
                                       
                                            <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Key Feature 1</label>
                                                <input type="text" class="form-control" name="kf1" placeholder="Key Feature 1" required/>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                             <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Key Feature 2</label>
                                                <input type="text" class="form-control" name="kf2" placeholder="Key Feature 2" required/>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     
                                      <div class="row">
                                       
                                            <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Key Feature 3</label>
                                                <input type="text" class="form-control" name="kf3" placeholder="Key Feature 3" required/>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                             <div class="col-md-6">
                                             <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Key Feature 4</label>
                                                <input type="text" class="form-control" name="kf4" placeholder="Key Feature 4" required/>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                      <div class="row">
                                       
                                            <div class="col-md-12">
                                             <div class="mb-3">
                                                <label for="validationCustom02" class="form-label">Postback URL</label>
                                                <input type="text" class="form-control" name="url" placeholder="eg: https://xyz.com?name='+name+'&email='+email+'&mobile='+mobile"/>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <input type="hidden" value="<?php echo $listv['id'];?>" name="agid">
                                        <input class="btn btn-primary" name="submit" type="submit">
                                    </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>    
                <?php }?>
<?php
if(isset($_POST['submit'])){
    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
$date_time=date('d/m/Y H:i:s a');
$agid=mysqli_real_escape_string($con,$_POST['agid']);
$name=mysqli_real_escape_string($con,$_POST['name']);
$kf1=mysqli_real_escape_string($con,$_POST['kf1']);
$kf2=mysqli_real_escape_string($con,$_POST['kf2']);
$kf3=mysqli_real_escape_string($con,$_POST['kf3']);
$kf4=mysqli_real_escape_string($con,$_POST['kf4']);
$url=mysqli_real_escape_string($con,$_POST['url']);
	$logo=mysqli_real_escape_string($con,$_FILES['logo']['name']);
	$image=mysqli_real_escape_string($con,$_FILES['image']['name']);
	$banner=mysqli_real_escape_string($con,$_FILES['banner']['name']);
$check_user=mysqli_num_rows(mysqli_query($con,"select * from pages where name='$name'"));
if($check_user>0){
    ?>
    <script>Swal.fire({
  position: 'top-end',
  icon: 'error',
  title: 'User already exist',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="pages";
}, "2600")</script>
    
<?php
}else{
    			            if($_FILES['logo']['name']!=''){
				 $photo=$_FILES['logo']['name'];
				$ext=explode('.',$_FILES['logo']['name']);
				$ext_check=strtolower(end($ext));
				$valid_ext=array('png','jpg','jpeg');
				if(in_array($ext_check,$valid_ext)){
					move_uploaded_file($_FILES['logo']['tmp_name'],'../uploads/'.$photo);
				}
    			}
    			            if($_FILES['image']['name']!=''){
				 $photo=$_FILES['image']['name'];
				$ext=explode('.',$_FILES['image']['name']);
				$ext_check=strtolower(end($ext));
				$valid_ext=array('png','jpg','jpeg');
				if(in_array($ext_check,$valid_ext)){
					move_uploaded_file($_FILES['image']['tmp_name'],'../uploads/'.$photo);
				}
    			}
    			            if($_FILES['banner']['name']!=''){
				 $photo=$_FILES['banner']['name'];
				$ext=explode('.',$_FILES['banner']['name']);
				$ext_check=strtolower(end($ext));
				$valid_ext=array('png','jpg','jpeg');
				if(in_array($ext_check,$valid_ext)){
					move_uploaded_file($_FILES['banner']['tmp_name'],'../uploads/'.$photo);
				}
    			}
	mysqli_query($con,"insert into pages(agency_id,name,logo,banner,image,kf1,kf2,kf3,kf4,url,timestamp,status) values('$agid','$name','$logo','$banner','$image','$kf1','$kf2','$kf3','$kf4',$url,'$date_time','0')");

	
					?>
        <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Page Added Successfully',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="pages";
}, "2600")</script>
  <?php
}
}
?>
<?php 

    if(isset($_POST['lead-deletee'])){
        $ldid=mysqli_real_escape_string($con,$_POST['deleteid']);
        mysqli_query($con,"delete from pages where id='$ldid'");?>
                <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Page Deleted',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="pages";
}, "2600")</script>
<?php }?>
<?php 

    if(isset($_POST['lead-delete'])){
        $ldid=mysqli_real_escape_string($con,$_POST['deleteid']);
        mysqli_query($con,"update pages set status='0' where id='$ldid'");?>
                <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Page Deactive',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="pages";
}, "2600")</script>

<?php }
    if(isset($_POST['lead-active'])){
        $ldid=mysqli_real_escape_string($con,$_POST['activeid']);
        mysqli_query($con,"update pages set status='1' where id='$ldid'");?>
                <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Page Active',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="pages";
}, "2600")</script>
<?php }?>
<?php require('footer.php');?>
        <?php }else{
        header('location:auth-login');
        }
        ?>