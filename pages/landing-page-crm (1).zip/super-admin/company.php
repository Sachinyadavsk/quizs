<?php 
session_start();
if(isset($_SESSION['SUPER_ADMIN_LOGIN'])&&$_SESSION['SUPER_ADMIN_LOGIN']=='yes'){
?>
<?php require('html-header.php');?>
<?php require('top-header.php');?>
<?php require('left-sidebar.php');?>
<?php require('connection.php');?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                
                <div class="row">
                            <div class="col-12">
                                <div class="card" style="height: 495px; overflow: hidden auto;" data-simplebar="init">
                                    <div class="card-header">
                                        <div class="card-icon text-muted"><i class="fas fa-sync-alt fs-14"></i></div>
                                        <h3 class="card-title">Agencies</h3>
                                       <!--<div class="card-addon dropdown">
                                            <a href="javascript:void();" data-bs-toggle="modal" data-bs-target="#modalll">
                                            <button class="btn btn-label-success btn-sm"> <i class="fas fa-plus fs-12 align-middle ms-1"></i></button>
                                            </a>
                                        </div>-->
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive-md">
                                            <table id="datatable-col-visiblility" class="table text-nowrap mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>City</th>
                                                        <th>State</th>
                                                        <th>IP</th>
                                                        <th>Device</th>
                                                        <th>Location</th>
                                                        <th>Allowed Pages</th>
                                                        <th>Added On</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php
                                                $cat_res=mysqli_query($con,"select * from agency order by id desc");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $list){
                                                ?>
                                                    <tr>
                                                        <td class="align-middle"><?php echo $list['name'];?></td>
                                                        <td class="align-middle"><?php echo $list['email'];?></td>
                                                        <td class="align-middle"><?php echo $list['mobile'];?></td>
                                                        <td class="align-middle"><?php echo $list['city'];?></td>
                                                        <td class="align-middle"><?php echo $list['state'];?></td>
                                                        <td class="align-middle"><?php echo $list['ip'];?></td>
                                                        <td class="align-middle"><?php echo $list['device'];?></td>
                                                        <td class="align-middle"><?php echo $list['loc'];?></td>
                                                        <td class="align-middle"><?php echo $list['allowed_pages'];?></td>
                                                        <td class="align-middle"><?php echo $list['timestamp'];?></td>
                                                        <td class="align-middle"><?php echo $list['status'];?></td>
                                                        
                                                       
                                                        <td class="align-middle">
                                                           
                                                            <a href="javascript:void();" data-bs-toggle="modal" data-bs-target="#modal<?php echo $list['id'];?>" title="Edit Lead">
                                                            <i class="fas fa-edit" style="color:blue"></i>
                                                            </a>
                                                           
                                                                <?php if($list['status']==1){?>
                                                            <form action="" method="post">
                                                                <input type="hidden" value="<?php echo $list['id'];?>" name="deleteid">
                                                           <button type="submit" name="lead-delete" style="border:none; background:none;"><i class="fas fa-trash" style="color:#92f77c"></i>
                                                            </button>
                                                            </form>
                                                          <?php }else{?>
                                                          <form action="" method="post">
                                                                <input type="hidden" value="<?php echo $list['id'];?>" name="activeid">
                                                           <button type="submit" name="lead-active" style="border:none; background:none;"><i class="fas fa-trash" style="color:red"></i>
                                                            </button>
                                                            </form>
                                                            <?php }?>
                                                        </td>
                                                    </tr>
                                                    <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                        
                    
                    </div>
                    </div>
                    </div>
                    <?php 
                    $a='';
                   
         
                                                $cat_res=mysqli_query($con,"select * from agency");
                                                $cat_arr=array();
                                                while($row=mysqli_fetch_assoc($cat_res)){
                                                  $cat_arr[]=$row;    
                                                }
                                                 foreach($cat_arr as $list){
                                                     $llid=$list['id'];
                                               $a=$list['allowed_pages'];
                                         
                                                 
                                                
                    
                    ?>
<div class="modal fade" id="modal<?php echo $list['id'];?>">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Update</h5><button type="button" class="btn btn-sm btn-label-danger btn-icon" data-bs-dismiss="modal"><i class="mdi mdi-close"></i></button>
                            </div>
                            <div class="modal-body">
                                <div class="card">
                            <div class="card-body">
                                <form class="needs-validation" action="" method="post" novalidate>
                                    <div class="row">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="validationCustom01" class="form-label">Allowed Pages</label>
                                                <input type="number" class="form-control" id="validationCustom01" name="ap"  value="<?php echo $a;?>" min="1" max="10"required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                        </div>
                                       
                                                <input type="hidden" name="agency_id" value="<?php echo $llid;?>">
                                    <div>
                                        <input class="btn btn-primary" name="register-submit" type="submit">
                                    </div>
                                    </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                    <?php }?>
                  
                    <?php
date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
$date_time=date('d/m/Y H:i:s a');
if(isset($_POST['register-submit'])){
   $agency_id=mysqli_real_escape_string($con,$_POST['agency_id']);
$ap=mysqli_real_escape_string($con,$_POST['ap']);
mysqli_query($con,"update agency set allowed_pages='$ap' where id='$agency_id'");
			?>
        <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Updated Successfully',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="agencies";
}, "2600")</script>
  <?php
}
?>

<?php 
    if(isset($_POST['lead-delete'])){
        $ldid=mysqli_real_escape_string($con,$_POST['deleteid']);
        mysqli_query($con,"update agency set status='0' where id='$ldid'");
        ?>
                <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Agency Deactive',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="agencies";
}, "2600")</script>
<?php }
    if(isset($_POST['lead-active'])){
        $ldid=mysqli_real_escape_string($con,$_POST['activeid']);
                mysqli_query($con,"update agency set status='1' where id='$ldid'");
        ?>
                <script>Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Agency Active',
  showConfirmButton: false,
  timer: 2500
})
setTimeout(() => {
  window.location.href="agencies";
}, "2600")</script>
<?php }?>
?>
	<script>
function get_city(){
			var id=jQuery('#validationCustom03aa').val();
				jQuery.ajax({
					type:'post',
					url:'get_data.php',
					data:'id='+id+'&type=city',
					success:function(result){
						jQuery('#validationCustom03bb').html(result);
					}
				});

}
	</script>
<?php require('footer.php');?>
        <?php }else{
        header('location:auth-login');
        }
        ?>
        